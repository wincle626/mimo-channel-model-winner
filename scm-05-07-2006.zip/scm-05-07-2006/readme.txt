MATLAB implementation of SCM channel model
Version 1.21
July 5, 2006

Requires MATLAB 6.5.0 (R13) or later.


Installation instructions:

Create a directory called 'winner', copy all files in this zip into the directory, and add the directory to Matlab's path. To get started, type 'help winner'. 



CHANGE HISTORY:

July 5, 2006 (v1.21)
- a minor bug in scm_mex_core.c corrected, computation remains unaffected.
- minor changes in ds.m and cas.m, help text edited in pathloss.m

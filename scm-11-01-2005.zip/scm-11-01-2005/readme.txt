MATLAB implementation of SCM channel model
Version 1.2
Jan 11, 2005

Requires MATLAB 6.5.0 (R13) or later.


Installation instructions:

Create a directory called 'winner', copy all files in this zip into the directory, and add the directory to Matlab's path. To get started, type 'help winner'. 


